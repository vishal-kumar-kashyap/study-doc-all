# tree-builder

Create a simple ASCII tree from a folder structure

![Screenshot of the tool](screenshot.png?raw=true "Screenshot")